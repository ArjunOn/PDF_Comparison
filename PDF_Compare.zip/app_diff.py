from flask_ngrok import run_with_ngrok
import io
from flask import Flask, render_template, request
from PIL import Image
from flask import send_file
import numpy as np
import cv2
from werkzeug.utils import secure_filename
from flask import send_from_directory
import os
from openpyxl import load_workbook
import camelot
from pandas import  ExcelWriter
import xlsxwriter
import pdfkit
from flask_ngrok import run_with_ngrok
from PyPDF2 import PdfFileReader
import zipfile
import time, os, fnmatch, shutil
from pdf_diff import PDF_Image_Compare
import sys
import pdftotext
from flask import Response





app = Flask(__name__)

path = os.getcwd()

app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0
app.config['UPLOAD_FOLDER']='uploads'
app.config['Results_Folder']='results'
app.config['templates_folder']='templates'


compare = PDF_Image_Compare()



#os.makedirs(os.path.join(app.instance_path, 'images'), exist_ok=True)

@app.route("/",methods=['GET'])
def index():
    return render_template('index.html')


@app.route("/", methods=['GET', 'POST'])
def upload():
	if request.method == 'POST' :
		#file_to_be_saved = request.files.getlist("files")
		#for f in request.files.getlist("files"):
			#file_to_be_saved = request.files['first_file']
		file1=secure_filename(request.files['first_file'].filename)
		file2=secure_filename(request.files['second_file'].filename)
		print("*"*100)
		# print("request.files['file'].filename",f.filename)
		# print("Type of file:",type(file))
		# print(file)
		t = time.localtime()
		timestamp = time.strftime('%b-%d-%Y_%H%M', t)
		os.makedirs(os.path.join(path, 'uploads'),exist_ok=True)
		request.files['first_file'].save(os.path.join(app.config['UPLOAD_FOLDER'], request.files['first_file'].filename[:-4]+'-'+str(timestamp)+'.pdf'))
		request.files['second_file'].save(os.path.join(app.config['UPLOAD_FOLDER'], request.files['second_file'].filename[:-4]+'-'+str(timestamp)+'.pdf'))

		print("File Saved")
		print("*"*100)
		files=os.listdir(app.config['UPLOAD_FOLDER'])
		print(os.path.join(app.config['UPLOAD_FOLDER'],files[0]))

		changes = compare.compare_pdf(os.path.join(app.config['UPLOAD_FOLDER'],files[0]), os.path.join(app.config['UPLOAD_FOLDER'],files[1]))
		with open(os.path.join(app.config['templates_folder'],'out_file_large_v2.html'), 'w', encoding='utf-8') as out_file:
		    out_file.write(changes)
		shutil.rmtree(app.config['UPLOAD_FOLDER'])
		#return send_file(img_io, mimetype='image/png', attachment_filename='image' ,as_attachment=True)
		return render_template('out_file_large_v2.html')

if __name__ == "__main__":
    app.run(host='10.8.4.187',port='5000',debug=True)
    #app.run()