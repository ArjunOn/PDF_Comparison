import difflib
import pdftotext

class PDF_Image_Compare:


	@staticmethod
	def compare_pdf(pdf_1, pdf_2):

		with open(pdf_1,'rb') as f, open(pdf_2,'rb') as g:
			pdf1=pdftotext.PDF(f)
			pdf2=pdftotext.PDF(g)
			pdf1="\n\n".join(pdf1)
			pdf2="\n\n".join(pdf2)
			flines=pdf1.split('\n')
			glines=pdf2.split('\n')
			html_diff = difflib.HtmlDiff()
			diff = html_diff.make_file(fromlines=flines, tolines=glines)
		return diff