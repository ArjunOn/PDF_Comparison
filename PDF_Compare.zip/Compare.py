import difflib
import re
import os
def textCompare():
    d = difflib.Differ()
    cur = str("sdcsdcvdv").splitlines()
    old = str("yjmfdsrghtngb").splitlines()
    
    diff = d.compare(cur, old)
    rmListOld = []
    for kk in diff:
        if str(kk).startswith('+ '):
            rmListOld.append(kk[2:]+"\n")
            
    newListOld = []
    for each in str(str(old).strip()).split("\n"):
        for one in rmListOld:
            if len(one) > 0:
                if str(each).strip() == str(one).strip():
                    if len(str(each).strip()) > 1: 
                        newListOld.append("<font color='#ff0'>"+each+"</font>"+"\n")
                        break
        newListOld.append(each+"\n")
    l3 = [x for x in newListOld if x not in rmListOld]    
    finalTextOld = "".join(l3)  
    finalTextOld = re.sub(r'(\n\s*)+\n+', '\n\n', finalTextOld)
    finalTextOld = os.linesep.join([s for s in finalTextOld.splitlines() if s])
    
    diffNew = d.compare(old,cur)
    rmListNew = []
    for kk in diffNew:
        if str(kk).startswith('+ '):
            rmListNew.append(kk[2:]+"\n")
    
    
    newListNew = []
    for each in str(str(cur).strip()).split("\n"):
        for one in rmListNew:
            if len(one) > 0:
                if str(each).strip() == str(one).strip():
                    if len(str(each).strip()) > 1: 
                        newListNew.append("<font color='#fff'>"+each+"</font>"+"\n")
                        break
        newListNew.append(each+"\n")

    l4 = [x for x in newListNew if x not in rmListNew]    
    finalTextNew = "".join(l4)  

    finalTextNew = re.sub(r'(\n\s*)+\n+', '\n\n', finalTextNew)
    
    josn = {"AboutLatest":finalTextNew,"AboutCurrent":finalTextOld}
    print (josn)
    
textCompare()
            
