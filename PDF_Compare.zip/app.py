from flask_ngrok import run_with_ngrok
import io
from flask import Flask, render_template, request
from PIL import Image
from flask import send_file
import numpy as np
import cv2
from werkzeug.utils import secure_filename
from flask import send_from_directory
import os
from openpyxl import load_workbook
import camelot
from pandas import  ExcelWriter
import xlsxwriter
import pdfkit
from flask_ngrok import run_with_ngrok
from PyPDF2 import PdfFileReader
import zipfile
import time, os, fnmatch, shutil
from pdf_compare import PDF_Image_Compare
import sys
from flask import Response





app = Flask(__name__)

path = os.getcwd()

app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0
app.config['UPLOAD_FOLDER']='uploads'
app.config['Results_Folder']='results'

compare = PDF_Image_Compare()



#os.makedirs(os.path.join(app.instance_path, 'images'), exist_ok=True)

@app.route("/",methods=['GET'])
def index():
    return render_template('index.html')


@app.route("/", methods=['GET', 'POST'])
def upload():
	if request.method == 'POST' :
		file_to_be_saved = request.files.getlist("files")
		for f in file_to_be_saved:
			print(f)
			file=secure_filename(f.filename)
			print("*"*100)
			print("request.files['file'].filename",f.filename)
			print("Type of file:",type(file))
			print(file)
			t = time.localtime()
			timestamp = time.strftime('%b-%d-%Y_%H%M', t)
			os.makedirs(os.path.join(path, 'uploads'),exist_ok=True)
			f.save(os.path.join(app.config['UPLOAD_FOLDER'], f.filename[:-4]+'-'+str(timestamp)+'.pdf'))
			print("File Saved")
			print("*"*100)
		files=os.listdir(app.config['UPLOAD_FOLDER'])
		print(os.path.join(app.config['UPLOAD_FOLDER'],files[0]))
		changes = compare.compute_changes(os.path.join(app.config['UPLOAD_FOLDER'],files[0]), os.path.join(app.config['UPLOAD_FOLDER'],files[1]), top_margin=float(0), bottom_margin=float(100))
		img = compare.render_changes(changes, ['strike', 'underline'], 1900)
		img_io = io.BytesIO()
		img.save(img_io,'png', quality=70)
		img_io.seek(0)
		shutil.rmtree(app.config['UPLOAD_FOLDER'])
		return send_file(img_io, mimetype='Compared_image/jpg', attachment_filename='Compared_image' ,as_attachment=True)

if __name__ == "__main__":
    app.run(host='127.0.0.1',port='5000',debug=True)
    #app.run()